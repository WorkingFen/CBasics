#include <lib.h>
#include <minix/type.h>
#include <minix/callnr.h>
#include <stdio.h>
#include <stdlib.h>

int getprocnr(int);

int main(int argc, char** argv) {
 int pid, result, i;

 if(argc<2) return -1;

 pid = atoi(argv[1]);

 for(i=pid; i<= pid+10; i++) {
 	printf("ProcID::( %d ) : ", i);

 	result = getprocnr(i);

 	if(result >= 0) printf("ProcNR::( %d )\n", result);
	else if(result == -3) printf("ERROR::(ESRCH)\n");
 	else printf("ERROR::( %d )\n", result);
 }
}

int getprocnr(int pid) {
 message msg;
 msg.m1_i1 = pid;
 _syscall(MM, GETPROCNR, &msg);
 return msg.m_type;
}
